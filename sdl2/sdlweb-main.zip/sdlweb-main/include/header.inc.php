<div id="header">                
    <div id="download_hint" class="box">
        Get the current <strong>stable</strong> <a href="https://github.com/libsdl-org/SDL/releases/latest">SDL version 3.2.26</a><br />
    </div>
</div>  
