 <meta charset="utf-8" />
 <link rel="icon" type="image/ico" href="/favicon.ico">
 <link rel="stylesheet" href="/css/fontfacekit/stylesheet.css">
 <link rel="stylesheet" href="/css/stylesheet.css">
 <meta name="keywords" content="SDL, Simple DirectMedia Layer, Download" />
 <script src="/js/SDL.js" type="text/javascript"></script>
