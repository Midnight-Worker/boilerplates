<div id="footer">
    <div id="light_theme" onclick="switch_theme('light')" class="button theme">Light Theme</div>
    <div id="dark_theme" onclick="switch_theme('dark')" class="button theme">Dark Theme</div>
    
    <!--
    Site actions: <a href="/login.php">User login</a> | <a href="/users.php">New account</a> 
    -->
</div>
