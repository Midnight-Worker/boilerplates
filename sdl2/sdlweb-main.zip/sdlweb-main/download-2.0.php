<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="refresh" content="3; url='https://github.com/libsdl-org/SDL/releases/latest'" />
  </head>
  <body>
    <p>This has been moved to GitHub. You should be redirected there shortly, or you can click <a href="https://github.com/libsdl-org/SDL/releases/latest">this link</a> to continue.</p>
  </body>
</html>
