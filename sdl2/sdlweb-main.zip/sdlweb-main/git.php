<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="refresh" content="3; url='https://github.com/libsdl-org'" />
  </head>
  <body>
    <p>This has been moved to GitHub. You should be redirected there shortly, or you can click <a href="https://github.com/libsdl-org">this link</a> to continue.</p>
  </body>
</html>
