#ifndef _LIBPORT_CONFIG_H_
#define _LIBPORT_CONFIG_H_

/* Define to 1 if you have the `getopt' function. */
/* #define HAVE_GETOPT 0 */

/* Define to 1 if you have the <unistd.h> header file. */
/* #define HAVE_UNISTD_H 0 */

#endif /* _LIBPORT_CONFIG_H_ */
