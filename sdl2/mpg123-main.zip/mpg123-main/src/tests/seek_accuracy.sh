#!/bin/sh
exec src/tests/seek_accuracy "$srcdir/src/tests/sweep.mp3"
