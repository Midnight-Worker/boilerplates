This reads from a webcam and draws frames of video to the screen.
