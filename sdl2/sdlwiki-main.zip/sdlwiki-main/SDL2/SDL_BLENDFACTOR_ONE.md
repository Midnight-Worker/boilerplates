# SDL_BLENDFACTOR_ONE

Please refer to [SDL_BlendFactor](SDL_BlendFactor) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

