# SDL_CONTROLLER_BUTTON_INVALID

Please refer to [SDL_GameControllerButton](SDL_GameControllerButton) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

