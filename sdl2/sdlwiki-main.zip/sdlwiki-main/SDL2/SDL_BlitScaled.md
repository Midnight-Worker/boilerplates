# SDL_BlitScaled

Please refer to [SDL_UpperBlitScaled](SDL_UpperBlitScaled) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIMacro](CategoryAPIMacro)

