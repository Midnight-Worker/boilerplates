# SDLK_KP_PERIOD

Please refer to [SDL_KeyCode](SDL_KeyCode) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

