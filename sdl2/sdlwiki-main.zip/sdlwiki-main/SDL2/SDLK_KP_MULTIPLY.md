# SDLK_KP_MULTIPLY

Please refer to [SDL_KeyCode](SDL_KeyCode) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

