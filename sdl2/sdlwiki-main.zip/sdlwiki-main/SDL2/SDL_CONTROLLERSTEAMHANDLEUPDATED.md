# SDL_CONTROLLERSTEAMHANDLEUPDATED

Please refer to [SDL_EventType](SDL_EventType) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

