# SDL_CONTROLLERUPDATECOMPLETE_RESERVED_FOR_SDL3

Please refer to [SDL_EventType](SDL_EventType) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

