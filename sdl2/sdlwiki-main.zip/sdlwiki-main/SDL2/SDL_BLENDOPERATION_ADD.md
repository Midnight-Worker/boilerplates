# SDL_BLENDOPERATION_ADD

Please refer to [SDL_BlendOperation](SDL_BlendOperation) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

