We track future plans in [GitHub milestones](https://github.com/libsdl-org/SDL/milestones) now.

