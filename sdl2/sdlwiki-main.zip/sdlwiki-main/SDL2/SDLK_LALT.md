# SDLK_LALT

Please refer to [SDL_KeyCode](SDL_KeyCode) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

