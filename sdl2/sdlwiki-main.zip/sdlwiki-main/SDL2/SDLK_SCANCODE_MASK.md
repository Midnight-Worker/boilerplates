# SDLK_SCANCODE_MASK

Please refer to [SDL_Keycode](SDL_Keycode) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIMacro](CategoryAPIMacro)

