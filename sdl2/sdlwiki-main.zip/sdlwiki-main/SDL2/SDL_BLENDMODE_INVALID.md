# SDL_BLENDMODE_INVALID

Please refer to [SDL_BlendMode](SDL_BlendMode) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

