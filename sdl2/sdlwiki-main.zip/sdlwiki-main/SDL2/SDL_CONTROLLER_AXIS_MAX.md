# SDL_CONTROLLER_AXIS_MAX

Please refer to [SDL_GameControllerAxis](SDL_GameControllerAxis) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

