# Moved

This page has moved to [/SDL2/README-linux](/SDL2/README-linux).

