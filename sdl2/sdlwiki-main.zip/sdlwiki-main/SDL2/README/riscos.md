# Moved

This page has moved to [/SDL2/README-riscos](/SDL2/README-riscos).

