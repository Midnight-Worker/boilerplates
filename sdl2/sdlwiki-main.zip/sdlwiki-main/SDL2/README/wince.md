# Moved

This page has moved to [/SDL2/README-wince](/SDL2/README-wince).

