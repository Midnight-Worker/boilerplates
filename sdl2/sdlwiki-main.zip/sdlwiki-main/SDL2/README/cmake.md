# Moved

This page has moved to [/SDL2/README-cmake](/SDL2/README-cmake).

