# Moved

This page has moved to [/SDL2/README-directfb](/SDL2/README-directfb).

