# Moved

This page has moved to [/SDL2/README-visualc](/SDL2/README-visualc).

