# Moved

This page has moved to [/SDL2/README-kmsbsd](/SDL2/README-kmsbsd).

