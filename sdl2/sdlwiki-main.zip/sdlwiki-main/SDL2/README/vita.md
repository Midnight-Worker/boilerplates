# Moved

This page has moved to [/SDL2/README-vita](/SDL2/README-vita).

