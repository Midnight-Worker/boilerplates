# Moved

This page has moved to [/SDL2/README-ios](/SDL2/README-ios).

