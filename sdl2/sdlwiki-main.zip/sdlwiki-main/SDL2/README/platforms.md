# Moved

This page has moved to [/SDL2/README-platforms](/SDL2/README-platforms).

