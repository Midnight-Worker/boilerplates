# Moved

This page has moved to [/SDL2/README-dynapi](/SDL2/README-dynapi).

