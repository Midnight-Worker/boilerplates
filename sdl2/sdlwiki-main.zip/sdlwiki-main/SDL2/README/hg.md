# Moved

This page has moved to [/SDL2/README-hg](/SDL2/README-hg).

