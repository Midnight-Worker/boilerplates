# Moved

This page has moved to [/SDL2/README-emscripten](/SDL2/README-emscripten).

