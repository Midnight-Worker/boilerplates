# Moved

This page has moved to [/SDL2/README-windows](/SDL2/README-windows).

