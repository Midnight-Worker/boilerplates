# Moved

This page has moved to [/SDL2/README-versions](/SDL2/README-versions).

