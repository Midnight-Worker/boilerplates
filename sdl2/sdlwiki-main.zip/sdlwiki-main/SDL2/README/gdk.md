# Moved

This page has moved to [/SDL2/README-gdk](/SDL2/README-gdk).

