# SDLK_KP_LESS

Please refer to [SDL_KeyCode](SDL_KeyCode) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

