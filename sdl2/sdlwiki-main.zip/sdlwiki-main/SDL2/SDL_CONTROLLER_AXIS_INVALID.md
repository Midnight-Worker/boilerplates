# SDL_CONTROLLER_AXIS_INVALID

Please refer to [SDL_GameControllerAxis](SDL_GameControllerAxis) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

