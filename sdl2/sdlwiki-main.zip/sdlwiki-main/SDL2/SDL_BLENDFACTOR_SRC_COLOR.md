# SDL_BLENDFACTOR_SRC_COLOR

Please refer to [SDL_BlendFactor](SDL_BlendFactor) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

