# SDL_BLENDFACTOR_DST_ALPHA

Please refer to [SDL_BlendFactor](SDL_BlendFactor) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

