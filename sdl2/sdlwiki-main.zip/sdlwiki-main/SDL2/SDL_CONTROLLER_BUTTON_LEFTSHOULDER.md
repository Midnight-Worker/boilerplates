# SDL_CONTROLLER_BUTTON_LEFTSHOULDER

Please refer to [SDL_GameControllerButton](SDL_GameControllerButton) for details.

----
[CategoryAPI](CategoryAPI), [CategoryAPIEnumerators](CategoryAPIEnumerators)

