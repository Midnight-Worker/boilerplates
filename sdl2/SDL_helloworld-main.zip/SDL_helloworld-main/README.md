# SDL_helloworld

This is a simple skeleton program that builds an extremely simple SDL-based
program, setting up CI for GitHub Actions and such.

Feel free to use this as a starting point for your own code.

