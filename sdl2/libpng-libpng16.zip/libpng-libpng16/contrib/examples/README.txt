This directory (contrib/examples) contains examples of libpng usage.

NO COPYRIGHT RIGHTS ARE CLAIMED TO ANY OF THE FILES IN THIS DIRECTORY.

To the extent possible under law, the authors have waived all copyright and
related or neighboring rights to this work.  This work is published from:
United States.

The files may be used freely in any way.  The intention is that appropriate
parts of the files be used in other libpng-using programs without any need for
the authors of the using code to seek copyright or license from the original
authors.

The source code and comments in this directory are the original work of the
people named below.  No other person or organization has made contributions to
the work in this directory.

ORIGINAL AUTHORS
    The following people have contributed to the code in this directory.  None
    of the people below claim any rights with regard to the contents of this
    directory.

    John Bowler <jbowler at acm.org>
